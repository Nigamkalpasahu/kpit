#ifndef OWNER_H
#define OWNER_H

#include <string>

class Vehicle; // Forward declaration

class Owner {
public:
    std::string name;
    std::string location;
    Vehicle* vehicleOwned;
    virtual float PayRegistrationPharges() const = 0;
};

class PrivateVehicleOwner : public Owner {
public:
    std::string aadharCardNumber;
    float PayRegistrationPharges() const override;
};

class CommercialOwner : public Owner {
public:
    std::string GSTNumber;
    enum class Type { AGENCY, INDIVIDUAL };
    Type type;
    float PayRegistrationPharges() const override;
};

#endif
