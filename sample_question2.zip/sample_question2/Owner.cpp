#include "Owner.h"
#include "Vehicle.h"

float PrivateVehicleOwner::PayRegistrationPharges() const {
    return 0.1 * vehicleOwned->price;
}

float CommercialOwner::PayRegistrationPharges() const {
    return 0.2 * vehicleOwned->price;
}
