#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

class Vehicle {
public:
    int id;
    std::string name;
    std::string type;
    float price;
    int seatCount;
    std::string brand;
    std::string fuelType;
    std::string transmissionType;
};

#endif
