#ifndef VEHICLE_REGISTRY_H
#define VEHICLE_REGISTRY_H

#include <vector>
#include "Owner.h"

class VehicleRegistry {
private:
    std::vector<Owner*> owners;

public:
    void RegisterOwner(Owner* owner);
    void MoveData(Owner* fromOwner, Owner* toOwner);
    float GetAverageRegistrationAmount() const;
    float GetMinimumRegistrationAmount() const;
    float GetMaximumRegistrationAmount() const;
    std::vector<Vehicle*> GetVehiclesByCommercialOwnerType(CommercialOwner::Type type) const;
    std::vector<Owner*> GetLastNRegisteredOwners(int n) const;
    bool AreAllVehiclesAbovePriceThreshold(float threshold) const;
};

#endif
