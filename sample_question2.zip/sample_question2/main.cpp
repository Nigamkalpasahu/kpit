#include <iostream>
#include <thread>
#include "Vehicle.h"
#include "Owner.h"
#include "VehicleRegistry.h"

int main() {
    try {
        VehicleRegistry registry;

        // Register owners and vehicles
        
        // Create threads for processing registration and moving data
        std::thread thread1([&registry]() {
            try {
                float averageAmount = registry.GetAverageRegistrationAmount();
                std::cout << "Average Registration Amount: $" << averageAmount << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "Error in thread 1: " << e.what() << std::endl;
            }
        });

        std::thread thread2([&registry]() {
            try {
                float minAmount = registry.GetMinimumRegistrationAmount();
                std::cout << "Minimum Registration Amount: $" << minAmount << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "Error in thread 2: " << e.what() << std::endl;
            }
        });

        std::thread thread3([&registry]() {
            try {
                float maxAmount = registry.GetMaximumRegistrationAmount();
                std::cout << "Maximum Registration Amount: $" << maxAmount << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "Error in thread 3: " << e.what() << std::endl;
            }
        });

        // Join threads
        thread1.join();
        thread2.join();
        thread3.join();

        // Additional functionality demonstration
        // Retrieve details, output results, etc.
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
