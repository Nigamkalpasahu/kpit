#include "VehicleRegistry.h"
#include "Vehicle.h"  
#include <algorithm>
#include <stdexcept>

void VehicleRegistry::RegisterOwner(Owner* owner) {
    owners.push_back(owner);
}

void VehicleRegistry::MoveData(Owner* fromOwner, Owner* toOwner) {
    if (fromOwner->vehicleOwned != nullptr && toOwner->vehicleOwned == nullptr) {
        toOwner->vehicleOwned = fromOwner->vehicleOwned;
        fromOwner->vehicleOwned = nullptr;
    } else {
        throw std::invalid_argument("Invalid move operation.");
    }
}

float VehicleRegistry::GetAverageRegistrationAmount() const {
    if (owners.empty()) {
        throw std::logic_error("No owners registered.");
    }

    float sum = 0;
    for (Owner* owner : owners) {
        sum += owner->PayRegistrationPharges();
    }
    return sum / owners.size();
}

float VehicleRegistry::GetMinimumRegistrationAmount() const {
    if (owners.empty()) {
        throw std::logic_error("No owners registered.");
    }

    float minAmount = owners[0]->PayRegistrationPharges();
    for (Owner* owner : owners) {
        minAmount = std::min(minAmount, owner->PayRegistrationPharges());
    }
    return minAmount;
}

float VehicleRegistry::GetMaximumRegistrationAmount() const {
    if (owners.empty()) {
        throw std::logic_error("No owners registered.");
    }

    float maxAmount = owners[0]->PayRegistrationPharges();
    for (Owner* owner : owners) {
        maxAmount = std::max(maxAmount, owner->PayRegistrationPharges());
    }
    return maxAmount;
}

std::vector<Vehicle*> VehicleRegistry::GetVehiclesByCommercialOwnerType(CommercialOwner::Type type) const {
    std::vector<Vehicle*> vehicles;
    for (Owner* owner : owners) {
        CommercialOwner* commercialOwner = dynamic_cast<CommercialOwner*>(owner);
        if (commercialOwner && commercialOwner->type == type) {
            vehicles.push_back(owner->vehicleOwned);
        }
    }
    return vehicles;
}

std::vector<Owner*> VehicleRegistry::GetLastNRegisteredOwners(int n) const {
    if (n <= 0 || n > owners.size()) {
        throw std::out_of_range("Invalid value for N.");
    }

    int start = owners.size() - n;
    return std::vector<Owner*>(owners.begin() + start, owners.end());
}

bool VehicleRegistry::AreAllVehiclesAbovePriceThreshold(float threshold) const {
    for (Owner* owner : owners) {
        if (owner->vehicleOwned->price <= threshold) {
            return false;
        }
    }
    return true;
}
