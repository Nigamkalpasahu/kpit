// #include "Electricity.h"
// #include <iostream>
// using namespace std;

// // Default constructor
// Electricity::Electricity() {
//     sanctionLoad = 0;
//     electricityLab = 0;
//     presentReading = 0;
//     previousReading = 0;
//     consumption = 0;
// }

// // Getter and setter functions
// int Electricity::getSanctionLoad() const {
//     return sanctionLoad;
// }

// void Electricity::setSanctionLoad(int load) {
//     sanctionLoad = load;
// }

// int Electricity::getElectricityLab() const {
//     return electricityLab;
// }

// void Electricity::setElectricityLab(int lab) {
//     electricityLab = lab;
// }

// long Electricity::getPresentReading() const {
//     return presentReading;
// }

// void Electricity::setPresentReading(long present) {
//     presentReading = present;
// }

// long Electricity::getPreviousReading() const {
//     return previousReading;
// }

// void Electricity::setPreviousReading(long previous) {
//     previousReading = previous;
// }

// long Electricity::getConsumption() const {
//     return consumption;
// }

// void Electricity::setConsumption(long cons) {
//     consumption = cons;
// }

// // Function to calculate electricity bill
// long Electricity::CalculateElectricityBill() const {
//     return (sanctionLoad * electricityLab) + (consumption * electricityLab / 100);
// }

// // Function to accept details from the user
// void Electricity::accept() {
//     cout << "Enter Sanction Load: ";
//     cin >> sanctionLoad;
//     cout << "Enter Electricity Lab: ";
//     cin >> electricityLab;
//     cout << "Enter Present Reading: ";
//     cin >> presentReading;
//     cout << "Enter Previous Reading: ";
//     cin >> previousReading;
//     consumption = presentReading - previousReading;
// }

// // Function to display details
// void Electricity::display() const {
//     cout << "Sanction Load: " << sanctionLoad << endl;
//     cout << "Electricity Lab: " << electricityLab << endl;
//     cout << "Present Reading: " << presentReading << endl;
//     cout << "Previous Reading: " << previousReading << endl;
//     cout << "Consumption: " << consumption << endl;
// }

