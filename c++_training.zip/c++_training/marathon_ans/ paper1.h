#ifndef PAPER1.H
#define PAPER1.H
#include<iostream>
#include<string>
using namespace std;
class flight{
    string flightnumber;
    double distance;
    string flightType;
    double fuelquantity;
    double fare;
    
    public:
    flight(){
        flightnumber = "/0";
        distance = 0.0;
        flightType = "";
        fuelquantity = 0.0;
        fare = 0.0;
    }
    flight(string flightnumber, double distance, string flightType){
        this->flightnumber = flightnumber;
        this->distance = distance;
        this->flightType = flightType;
    }
    int calculatefare();
    int calculatefuel();
    void feedinfo();
    void showinfo();

    string get_flightnum();
    void set_flightnum();
    double get_distance();
    void set_distance();
    string get_flightType();
    void set_flightType();

    double get_fuelquantity();
    void set_fuelquantity();

    double get_fare();
    void set_fare();


};



#endif