#include"paper1.h"
 
 
int flight:: calculatefare(){
    if(distance<=1000){
        fare = 5000;
    }else if(distance>1000 && distance<=1500){
        fare = 11000;
    }else if (distance>1500 && distance<= 2000)
    {
        fare = 22000;
    } else{
        fare = 30000;
    }
    
};

int flight::calculatefuel(){
    if(distance<=1000){
        fuelquantity = 4000;
    }else if(distance>1000 && distance <= 1500){
        fuelquantity = 6000;
    }else if(distance>1500 && distance<= 2000){
        fuelquantity = 7500;
    }else{
        fuelquantity = 10000;
    }
}
void flight:: feedinfo(){
    cout<<"Enter the flightnumber: "<<endl;
    cin>>flightnumber;
    cout<<"Enter the distance: "<<endl;
    cin>>distance;
    cout<<"Enter the flight type: "<<endl;
    cin>>flightType;
}
void flight :: showinfo(){
 out << "Enter the flightnumber: " << flightnumber << endl;
cout << "Enter the distance: " << distance << endl;
cout << "Enter the flightType: " << flightType << endl;
 }