 #include "Electricity.h"
 #include "Electricity.cpp"
 #include<iostream>
 using namespace std;

int main() {
    // Create object of Electricity on the stack
    Electricity electricObj;

    // Accept details from user
    electricObj.accept();

    // Display details
    electricObj.display();

    // Calculate and display electricity bill
    std::cout << "Electricity Bill: $" << electricObj.CalculateElectricityBill() << std::endl;

    return 0;
}
