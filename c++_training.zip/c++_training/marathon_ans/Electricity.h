#ifndef ELECTRICITY.H
#define ELECTRICITYH
#include<iostream>
using namespace std;
class Electricity {
private:
    int sanctionLoad;
    int electricityLab;
    long presentReading;
    long previousReading;
    long consumption;

public:
    // Default constructor
    Electricity();

    // Getter and setter functions
    int getSanctionLoad() const;
    void setSanctionLoad(int load);

    int getElectricityLab() const;
    void setElectricityLab(int lab);

    long getPresentReading() const;
    void setPresentReading(long present);

    long getPreviousReading() const;
    void setPreviousReading(long previous);

    long getConsumption() const;
    void setConsumption(long consumption);

    // Function to calculate electricity bill
    long CalculateElectricityBill() const;

    // Function to accept details from the user
    void accept();

    // Function to display details
    void display() const;
};

#endif
