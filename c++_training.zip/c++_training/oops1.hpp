  #ifndef oops1_hpp
  #define oops1_hpp
  #include <iostream>
  using namespace std;
  int add(int x, int y){
    return x + y;
  }
  #endif