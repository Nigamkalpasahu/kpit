 #include<iostream>
 using namespace std;
 void fun(){
      throw 10;
 }

 int main(){
      cout<<"welcome"<<endl;
      try
      {
             //throw 10;
             fun();
             cout<<"in try "<<endl;
      }
      catch(int e)
      {
            cout<<"exception no is - "<< e <<endl;
      }

      cout<<"last line "<<endl;
      
 }