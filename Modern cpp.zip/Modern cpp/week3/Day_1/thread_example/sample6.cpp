/*
create an array of  3 threads

- thread 1 should calculate square of each number in the array and store in a
result array (position  1 to 5)

- thread 2 should calculate cube of each number in the array and store in a result 
array (position 6 to 10)

- thread 3 should calculate factorial of each number in the array and store 
  in a result array position 11 to 15

  Assumption : Number in the input array will be between  1 to 10
*/

// #include<iostream>
// #include<thread>
// #include<array>

// int main(){
//     std::array<int, 15> result;
//     std::array<std::thread, 4> arr{
//         std::thread(
//             [](int number, ) {result[i] = number * number; }
//         ),
//         std::thread(
//             [](int number, ) {result[i] = number * number; }
//         ),
//     }
// }
#include <iostream>
#include <thread>

void calculateSquare(int* numbers, int* result, int start, int end) {
    for (int i = start; i < end; ++i) {
        result[i] = numbers[i] * numbers[i];
    }
}// 

void calculateCube(int* numbers, int* result, int start, int end) {
    for (int i = start; i < end; ++i) {
        result[i + 5] = numbers[i] * numbers[i] * numbers[i];
    }
}

void calculateFactorial(int* numbers, int* result, int start, int end) {
    for (int i = start; i < end; ++i) {
        int num = numbers[i];
        int fact = 1;
        for (int j = 2; j <= num; ++j) {
            fact *= j;
        }
        result[i + 10] = fact;
    }
}

int main() {
    const int numElements = 5;
    int numbers[numElements] = {1, 2, 3, 4, 5};
    int result[15];

    std::thread t1(calculateSquare, numbers, result, 0, numElements);
    std::thread t2(calculateCube, numbers, result, 0, numElements);
    std::thread t3(calculateFactorial, numbers, result, 0, numElements);

    t1.join();
    t2.join();
    t3.join();

    for (int i = 0; i < 15; ++i) {
        std::cout << result[i] << " ";
    }

    return 0;
}