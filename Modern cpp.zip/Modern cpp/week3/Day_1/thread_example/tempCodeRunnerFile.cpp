#include <iostream>
#include <thread>
#include <mutex>
#include<array>
/*
    one object of this class will be responsible for one connection mechanism to the bank
*/           
           
class BankingOperation
{
private:
    int _amount {0};
    std::mutex mt;
    static BankingOperation* _solo_hero_obj;
    BankingOperation(int amount) : _amount{amount} {}
  

public:
    BankingOperation(const BankingOperation&) = delete;
    BankingOperation(BankingOperation &&) = delete;
    BankingOperation& operator=(const BankingOperation&) = delete;
    BankingOperation& operator=(BankingOperation &&) = delete;
    ~BankingOperation() = default;
    
    void Withdraw(){
    for (int i = 0; i < 100; i++) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        std::lock_guard<std::mutex> lk(mt);
        _amount -= 10;
     }

}

void Deposit(){
    for (int i = 0; i < 100; i++) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        std::lock_guard<std::mutex> lk(mt);
        _amount += 10;
    }
}

static  BankingOperation* getFirstInstance(int amount){
    // if pointer is not null (void) , object already exists
        if(_solo_hero_obj){
            //return address of existing object
            return _solo_hero_obj;
        }else{
            //no object is pre existing need to create new object
            _solo_hero_obj = new BankingOperation(amount);
            return _solo_hero_obj;
        }
}

int amount() const { return _amount; }

};

BankingOperation* BankingOperation::_solo_hero_obj {nullptr};

int main() {
    BankingOperation* obj = BankingOperation::getFirstInstance(1000); // value initializztion using {}
    
    std::array<std::thread, 2> arr = {
    std::thread(&BankingOperation::Withdraw,obj),
    std::thread(&BankingOperation::Deposit,obj)
};

for(std::thread& t : arr){
    //good practice
    if(t.joinable()){// true still wait.
        t.join();
    }
}
std::cout<<"Final amount is : "<< obj->amount() << "\n";
} 

//   