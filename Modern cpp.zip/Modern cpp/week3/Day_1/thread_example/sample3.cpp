#include<iostream>
#include<thread>
#include<mutex>
std::mutex mt;
/*
    withdraw : withdraw takes 10 unit of money from amount,
    deposit: adds 10 units of money to amount

    Run withdraw and deposit both for 100 times each on initial amount of 1000

    what                                will be  the final amount after 200 transactionare completed
*/

int amount = 1000;

void withdraw(){
    for(int i = 0; i< 100; i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        mt.lock();
        amount -= 100;
        mt.unlock();
    }
}

void deposit(){
    for(int i =0 ; i<100; i++){
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        mt.lock();
        amount += 100;
         mt.unlock();
    }
}
int main(){
    std::thread t1(withdraw);
    std::thread t2(deposit);

    t1.join();
    t2.join();

    std::cout <<"Final amount is " << amount << std::endl;

}

/*
    terminal for loop
    for((i=0; i<50; i++)); do ./app ; done
*/