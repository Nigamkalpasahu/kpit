/*
    Processor : It is a hardware device based on  SILICON which execute 
    instruction given
    ex - intel 15 , 12 gen

    Core: it is a section of the processor which is capable of 
    execute one whole process

    single thread single process synchromous program

    Delay : IO delay , CPU-BOUND delay
 
*/


#include<iostream>
#include<array>
#include<thread>

void Square(std::array<int , 5>& data){
    for(int n: data){
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout<<"square of the number is : " << n * n << std::endl;
    }
}

void Cube(std::array<int , 5>& data){
    for(int n: data){
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout<<"cube of the number is : " << n * n * n <<std::endl ;
    }
}

int main(){
    std::array<int , 5> data {1,2,3,4,5};
    Square(data);
    Cube(data);
}
