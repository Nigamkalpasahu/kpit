#include<iostream>
#include<array>
#include<thread>
#include<mutex>

std::mutex mt; //mutex is a binary semaphore

void Square(std::array<int , 5>& data){
    for(int n: data){
    std::this_thread::sleep_for(std::chrono::seconds(1));

    mt.lock();
    std::cout<<"square of the number is : " << n * n<<std::endl ;
    mt.unlock();
    }
}

void Cube(std::array<int , 5>& data){
    for(int n: data){
    std::this_thread::sleep_for(std::chrono::seconds(1));
    // only 1 executing entity should be doing this at a time
    mt.lock();
    std::cout<<"cube of the number is : " << n * n * n <<std::endl;
    mt.unlock();
    }
}
                                                                                       
int main(){
    //main threads starts , create an array in local stack memory
    std::array<int , 5> data {1,2,3,4,5};

    // we launch a new thread
    /*
        A thread is a mini program, As the devloper, t1 object is a "handel"
        for me to *intrest with the thread in some way. this t1 is attached
        square mini program . we have also passed "data" by reference which is required
        by the square function
    */
    std::thread t1(&Square, std::ref(data));

    /*
        this t2 is attached
        Cube mini program . we have also passed "data" by reference 
        which is required by the Cube function
    */
    std::thread t2(&Cube, std::ref(data));
    // signal as a result/sumary/satisfaction
    //join : wait for a thread
    t1.join();// main will not proceed to next line until t1 is finished
    t2.join();// main will not proceed to next line until t2 is finished

    std::cout<< "goodbye\n"; 
}
