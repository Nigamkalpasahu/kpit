#include <iostream>
#include <array>
#include <unordered_map>
int main() {
    //spread operator in js : similar
    std::array<int,2> data {60,923};
    auto [id,salary] = data; //val needed
   // auto&[id,salary] = data; //ref needed

    std::unordered_map<int,std::string> map {
        std::make_pair<int,std::string>(1,"Nigam"),
        std::make_pair<int,std::string>(2,"Kalpa")

    };
    for(auto& [k,v] : map){
        std::cout << "Key : " << k << std::endl;
        std::cout << "Value : " << v << std::endl;
    }
}