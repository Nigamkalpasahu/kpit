 /*
     if initializer 
     it only use in cpp 17
 */
 
 
 #include<iostream>
#include<vector>

std::vector<int> FindOddNumbers(std::vector<int>& data){
    std::vector<int> result;
    for(int val:data){
        if(val % 2!=0){
            result.push_back(val);
        }
    }

    return result;
}

int main(){
    std::vector<int> data{10,10,40,50,60,70};
    //std::vector<int> result=FindOddNumbers(data);
    if(std::vector<int> result=FindOddNumbers(data);result.empty()){
        std::cout<<"Invaid\n";

    }else{
        for(int val: result){
            std::cout<<val<<"\n";
        }
    }
}