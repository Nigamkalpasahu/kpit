// variadic templates
#include<iostream>


/*
add is a function that takes 2 parameters of type "int"
it uses them as operands for binary + operator and returns the result of 
+ operator applied on these operands
*/

// int add(int n1 , int n2){
//     return n1 + n2;
// }
// template in add
 template <typename T>
 T add(T n1){
    return n1;
 }

template <typename T , typename... Remaining>
T add (T n1 , Remaining... args){ // ... more than one 
    return n1 + add(args...);
}

// template <typename T>
// T add(T n1 , T n2){
//     return n1 + n2 ;
// }

int main(){
    std::cout<<add<int>(10 , 20)<<std::endl;
    std::cout<< add<float> (10.21f , 10.23f)<<std::endl;
    std::cout<< add<int> (100) <<std::endl;
}