// TaxPayers : Employees , BussinessOwner

// Algebraic Data type (ADT)
#include <iostream>
#include <variant>
#include <array>

/*
    TaxPayers : Employees, BusinessOwners
    variant is a type safe union(union in C)
*/


/*
    Algebraic Data Type (ADT)
*/
                               
class BusinessOwner {

private:
    std::string _name;
    std::string _companyGstNumber;
    float _revenue;
    float _expenses;

public:
    float CalculateTaxAmount() {return 0.3f * (_revenue - _expenses);}
    BusinessOwner(std::string name, std::string gst, float rev, float exp)
        : _name{name}, _companyGstNumber{gst}, _revenue{rev}, _expenses{exp} {}
    ~BusinessOwner() = default;

    std::string name() const { return _name; }

    float revenue() const { return _revenue; }

    float expenses() const { return _expenses; }
};

class Employee {
private:
    std::string _name;
    float _salary;

public:
    Employee(std::string name, float sal) : _name{name}, _salary{sal} {}
    ~Employee() = default;

using VType = std::variant<Employee*,BusinessOwner*>;
    std::string name() const { return _name; }
};
// it is another version of union 
/*
    I want to use standard array as a container of 
    variants where each variant is either of type employee pointer or 
    BusinessOwner pointer
*/
using VType = std::variant<Employee*,BusinessOwner*>;
using Container = std::array<VType,2>;

void CommonAction(Container& arr) {
    for(VType v : arr){
        std::visit(
            [](auto&&/*template parameter for lambda*/ val){std::cout << val->name() << std::endl;},
            v
        );
    }
}

/*
for each VType (variant) called "v",
   a) open variant and check if v holds an alternative of type bussinessOwner*

   b) If yes, get data from slot 1 of the variant (because slot 1 is for BussinessOwner*)
   Now , save rhis to a variable and access revenue
*/

// for common - visit functiom for uncommon use uncommonfunction one 

void UncommonFunction(Container& arr){
    for(   VType v : arr){
        if(std::holds_alternative< BusinessOwner*> (v) ){
        BusinessOwner* ow = std::get<1>(v);
        std::cout<< ow->revenue();
        }
    }
}
                              
int main() {
    Employee* emp = new Employee("nigam",564545.54f);
    BusinessOwner* bow = new BusinessOwner("kalpa","ABSAJSBA",12132232.43f, 232143.3f);
    Container arr {emp,bow};
    CommonAction(arr);
    UncommonFunction(arr);
}

// Senario 1 : I want to excute a function that is present in all types of the 
// variant e.g = getter for name 

// senario 2 : You want     