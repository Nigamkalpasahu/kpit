#include <iostream>

class Parent
{
private:

public:
  Parent() {}
  ~Parent() {}
  virtual void magic() = 0;  //pure virtual fn
};


class Child : public Parent
{
private:

public:
  Child() {}
  ~Child() {}
  void ChildDisplay() {
    std::cout<<"Done"<<std::endl;
  }
  void magic() override {
    std::cout<<"magic from child"<<std::endl;
  }
};

int main() {

float f1 = 6.969f;
//int n1 = (float) f1;         // C STYLE CAST.
//improved version is static_cast.
//It is using a syntax that is not c lang specific and has a assertion technique available.
int n1 = static_cast<int>(f1);
std::cout<<n1<<std::endl;       //lossy conversion


/*TYPE 2 : cast when parent-child runtime polymorphism is in picture.

  2.a Converting reference
  here if u r working with this type of casting, do use try catch block
*/
Parent *p1 = new Child();
try {
  Child &ch = dynamic_cast<Child&>(*p1);
} catch (const std::bad_cast &err) {
        std::cerr << err.what() << "\n";
}
//  2.b converting pointer : if conversion fails, we get nullptr
  Parent* ptr = new Child(); //upcasting
  ptr->magic(); //ptr is parent,fn is virtual
  // ptr->ChildDisplay() is not valid, so we use dynamic cast.
  Child* temp = dynamic_cast<Child*>(ptr);
  if (temp != nullptr) {
    temp->ChildDisplay();    
  }
}



/*
  parent class : Car
  child class : ev Car
    member fun : start charging, 

*/