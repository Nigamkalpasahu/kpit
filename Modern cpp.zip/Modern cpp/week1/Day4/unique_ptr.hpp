#ifndef UNIQUE_PTR_HPP
#define UNIQUE_PTR_HPP

#include<iostream>

template <typename T>
class unique_ptr
{
private:
    T* _mptr;

public:
    unique_ptr(T* ptr) : _mptr {ptr} {
        ptr = nullptr
    }

    unique_ptr(const T*) = delete;//copy
    unique_ptr& operator = (const T*) = delete;

    unique_ptr(T*&&) = default;//move
    unique_ptr& operator = (T*&&) = default;

    void Release(){delete _mptr; _mptr = nullptr; }

    ~unique_ptr(){delete _mptr;  _mptr = nullptr; }
    

};

#endif // UNIQUE_PTR_HPP
