#ifndef STACK_HPP
#define STACK_HPP
#include "StackEmptyException.hpp"
#include<list>
/*
    Front


*/
// [10     |    20  |   30  |       ]
//  ^                   ^       ^
//  |                   |       |
// front()              Back()  end()
// begin()

/* End()-- we will get Back 
    One element difference is there
*/
template <typename T>
class Stack
{
private:
    std::list<T> _data{};
    



public:
    Stack()=default;
    Stack(const Stack&)=delete;
    Stack& operator=(const Stack&)=delete;
    Stack(Stack&&)=default;
    Stack& operator=(Stack&&)=default;
    ~Stack();



    void Pop();

    void Push(T val);
    // {
    //     _data.push_back(val);
    // }
   // Push(template T);
    //push function accepts one item 'Val' of type T and return void

    T Peek();
    //Give or show last or top element of satck

    size_t Size(){
        return _data.size();
    }

    bool IsEmpty();


};


#endif // STACK_HPP


/*
                int
    <----------- 0 ----------->

    unsigned int
    0 ------------------------>

    unsigned long 
    0----------------------------------------------------------------------------------------->
    2^64

*/

// template<typename T>
// void Stack<T>::Push(T val){
//     _data.push_back(val);
// }

template <typename T>
inline Stack<T>::~Stack()
{

    
    // delete _data;
}

template <typename T>
inline void Stack<T>::Pop()
{
    if(_data.empty())
        {
            //throw data empty
            throw StackEmptyException("Satck is empty");


        }

        _data.pop_back();
}

template<typename T>
inline void Stack<T>::Push(T val){
    _data.push_back(val);
                                                          
}
template<typename T>
inline T Stack<T>::Peek(){
    if(_data.empty())
        {
            //throw stack empty
            throw StackEmptyException("Satck is empty");
        }
        return _data.back();
}

template<typename T>
bool Stack<T>::IsEmpty(){
    return _data.empty();
    }
//***************************
/*

     Throw StackEmptyException("Data is empty") //statement
     |
     |
     throw<expression>//2 parts of the statement
     |
     |
     throw constructor call i.e. function call
     throw  [   _msg="Data is Empty"        ]
            <---------NO NAME--------------->
     throw rvalue of type StackEmptyException
     |[catch Table]
     

     Throw<expression>
     throw Constructor call i.e. function call

*/

