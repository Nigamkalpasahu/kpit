#include<iostream>
#include "stack.hpp"
#include "StackEmptyException.hpp"
#include<list>

int main()
{
    Stack<int> st;
    st.Push(10);
    st.Push(20);
    int x=st.Peek();
    std::cout<<x<<" ";
    st.Pop();
    
    int y=st.Peek();
    std::cout<<y<<" ";


    
    return 0;
}
    
    
    

