#include<iostream>
#include <memory>
                                                 
                              
class  EXAMPLE1
{
private:
    std::string _name;
    int _id;
public:
     EXAMPLE1(int id, std::string name):_id{id}, _name{name} {}
    ~ EXAMPLE1() {}
};

void Dummy(){
    // EXAMPLE1* ex1 = new EXAMPLE1(10 , "Nigam");
    //std::shared_ptr<EXAMPLE1> sptr {new EXAMPLE1(10 , "Nigam")};
    std::shared_ptr<EXAMPLE1> sptr {std::make_shared<EXAMPLE1>(10 , "Nigam")};



    int n1 {0};
    std::cin >> n1;

    std::cout << 10/n1;

    // delete ex1;
}

int main(){
    try {
        Dummy();
    }catch (std::exception& ex){};
}




/*          
    Dummy()
heap
        ----------------------->[  10  | Nigam  ]
                                0x100h
    ex1
    [   0x100H  ]
    <---8 bytes--->
    0x11h      0x18h
    n1
    [   0   ]
    <--4 bytes-->
    0x45H    0x48H


*/

/*   
    data : pointer ex1
    function which is guranteed to execute each time an object is destroyed : destructor
    action before data (ex1) is destroyed :
    heap deallocation using delete ex1




    Smart pointers in modern cpp

    1) unique pointer
    2) shared pointer
    3) weak pointer (token which can convert to shared ptr)

*/