#include "Functionalities.h"
#include "ElectricCar.h"
void CreateObjects(std::vector<Car *> &data)
{
  data.push_back(
    new ElectricCar("Mahindra",200,360,456676.23,212,3.5,9.1)
    );
  data.push_back(
    new ElectricCar("Tata",250,250,1056676.23,112,7.1,4.75)
    );
}

void DeleteObjects(std::vector<Car *> &data) {
for (Car*p : data) {
  delete p;
}

}
