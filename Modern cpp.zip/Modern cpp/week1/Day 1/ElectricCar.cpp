#include "ElectricCar.h"

float ElectricCar::Drive() {
  return _range;
}

std::ostream &operator<<(std::ostream &os, const ElectricCar &rhs) {
  os << static_cast<const Car &>(rhs)
     << " Battery capacity: " << rhs._battery_capacity
     << " Time To Charge: " << rhs._time_to_charge
     << " Motor Power: " << rhs._motor_power
     << " Max Power: " << rhs._max_power
     << "Range: " << rhs._range;
  return os;
}

void ElectricCar::ShowElectricCarDetails() {
  std::cout << " Battery capacity: " << _battery_capacity
    << " Time To Charge: " << _time_to_charge
    << " Motor Power: " << _motor_power
    << " Max Power: " << _max_power
    << "Range: " << _range;
}

ElectricCar::ElectricCar(std::string name, int accleration, int top_speed, float price, int battery_capacity, float time_to_charge,float motor_power)
  :Car(name,accleration,top_speed,price), _battery_capacity{battery_capacity}, _time_to_charge{time_to_charge}, _motor_power{motor_power}
{}