#ifndef ELECTRICCAR_H
#define ELECTRICCAR_H
#include "Car.h"
#include <iostream>
class ElectricCar : public Car
{
private:
  int _battery_capacity {0};
  float _time_to_charge {0.0f};
  float _motor_power {0.0f};
  float _max_power {0.0f};
  float _range {0.0f};                     
                                         
public:
  ElectricCar() = default; //default constructor enabled
  ElectricCar(const ElectricCar&) = delete; // copy constructor disabled
  ElectricCar(ElectricCar&&) = delete; //disabled move constructor, c++ brand new
  ElectricCar& operator=(const ElectricCar&) = delete; //deleted copy assignment operator 
  ElectricCar& operator=(ElectricCar&&) = delete; // deleted move assignment operator, c++ brand new
  ~ElectricCar() = default; // default destructor enabled

  float Drive() override;
  void ShowElectricCarDetails();
  
  ElectricCar(std::string name, int accleration, int top_speed, float price, int battery_capacity, float time_to_charge,float motor_power);

  int batteryCapacity() const { return _battery_capacity; }
  void setBatteryCapacity(int battery_capacity) { _battery_capacity = battery_capacity; }

  float timeToCharge() const { return _time_to_charge; }
  void setTimeToCharge(float time_to_charge) { _time_to_charge = time_to_charge; }

  float motorPower() const { return _motor_power; }
  void setMotorPower(float motor_power) { _motor_power = motor_power; }

  float maxPower() const { return _max_power; }
  void setMaxPower(float max_power) { _max_power = max_power; }

  float range() const { return _range; }
  void setRange(float range) { _range = range; }

  friend std::ostream &operator<<(std::ostream &os, const ElectricCar &rhs);
  
};

#endif // ELECTRICCAR_H
