#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
  os << "Name: " << rhs._name
     << "Accleration: " << rhs._accleration
     << "Top Speed: " << rhs._top_speed
     << " Ex Showroom Price: " << rhs._ex_showroom_price;
  return os;
}//shortcut - ctlr+shift+p -> output stream -> select all -> add in source file

// // Member list initialization
// Car::Car(std::string name, int accleration, int top_speed, float price)
//   : _name{name}, _accleration{accleration}, _top_speed{top_speed}, _ex_showroom_price{price}
// {}

// std::ostream &operator<<(std::ostream &os, const Car &rhs) {
//   os << "_name: " << rhs._name
//      << " _accleration: " << rhs._accleration
//      << " _top_speed: " << rhs._top_speed
//      << " _ex_showroom_price: " << rhs._ex_showroom_price;
//   return os;
// }
