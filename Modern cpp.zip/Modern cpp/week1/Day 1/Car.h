#ifndef CAR_H
#define CAR_H
#include <iostream>
class Car
{
private:
  std::string _name {"Uno"};  // in class initialization
  int _accleration {0};
  int _top_speed {0};
  float _ex_showroom_price {0.0f};
public:
  Car() = default; //default constructor enabled
  Car(const Car&) = delete; // copy constructor disabled
  Car(Car&&) = delete; //disabled move constructor, c++ brand new
  Car& operator=(const Car&) = delete; //deleted copy assignment operator 
  Car& operator=(Car&&) = delete; // deleted move assignment operator, c++ brand new
  virtual ~Car() = default; // default destructor enabled

  //parameterized  constructor
  Car(std::string name,int accleration,int top_speed,float price);

  std::string name() const { return _name; }
  void setName(const std::string &name) { _name = name; }
  int accleration() const { return _accleration; }
  void setAccleration(int accleration) { _accleration = accleration; }
  int topSpeed() const { return _top_speed; }
  void setTopSpeed(int top_speed) { _top_speed = top_speed; }
  float exShowroomPrice() const { return _ex_showroom_price; }
  void setExShowroomPrice(float ex_showroom_price) { _ex_showroom_price = ex_showroom_price; }

  friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
  virtual float Drive() = 0;

  //friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
