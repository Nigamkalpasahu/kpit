#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "Car.h"
#include <vector>

/*createObjects is a top-level(global) function which takes one argument of type
std::vector to Car pointers BY VALUE. This function return void.Here copies 
are created which uses more memory. */

//void CreateObjects(std::vector<Car*> data);


/*createObjects is a top-level(global) function which takes one argument of type
std::vector to Car pointers BY REFERENCE. This function return void. */
void CreateObjects(std::vector<Car*>& data);

void DeleteObjects(std::vector<Car*>& data);
#endif // FUNCTIONALITIES_H
