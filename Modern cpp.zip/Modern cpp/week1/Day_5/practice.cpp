 #include <iostream>
#include <string>
using namespace std;

int main() {
    string choice;
    
    cout << "Enter 1 for pizza or 2 for burger: ";
    getline(cin, choice);

    // Process user's choice
    if (choice == "1") {
        cout << "Your pizza is ready.\n";
    } else if (choice == "2") {
        cout << "Your burger is ready.\n";
    } else {
        cout << "Invalid input. Please enter 1 for pizza or 2 for burger.\n";
        return 1; // Return non-zero to indicate failure
    }

    return 0;
}
