 #include<iostream>
 #include "Engine.h"

 enum class EngineType{
    DIESEL,
    PETROL
 };

 class EngineDummy
 {
 private:
   int _horsePwoer;
   EngineType _type;
 public:
     EngineDummy(int hp , EngineType type) : _type{type} , _horsePwoer{hp} {}
     EngineDummy() {}

     friend std::ostream &operator<<(std::ostream &os, const EngineDummy &rhs) {
         os << "_horsePwoer: " << rhs._horsePwoer
            << " _type: " << rhs._type;
         return os;
     }

    
 };

 int main(){
    EngineDummy e1 {700 , EngineType::PETROL};
 }

  




/*          
    Dummy()
                                 heap
        ----------------------->[  10  | Nigam  ]
                                0x100h
    ex1
    [   0x100H  ]
    <---8 bytes--->
    0x11h      0x18h
    n1
    [   0   ]
    <--4 bytes-->
    0x45H    0x48H


*/

/*   
    data : pointer ex1
    function which is guranteed to execute each time an object is destroyed : destructor
    action before data (ex1) is destroyed :
    heap deallocation using delete ex1




    Smart pointers in modern cpp

    1) unique pointer
    2) shared pointer
    3) weak pointer (token which can convert to shared ptr)

*/






































// #include <iostream>


// int addition(int n1 , int n2){
//     return n1 + n2;
// }

// int main(){
//     std::cout  << addition(10 , 20);
// }