#include "Functionality.h"
#include "EmptyContainerException.h"
#include "IdNotFoundException.h"
void CreateObjects(Container &data)
{
  data[0] = new Car("c101",5643545.34f,"city",new Engine(300,110.0f),CarType::SEDAN);
  data[1] = new Car("c102",453545.534f,"dzire",new Engine(400,220.0f),CarType::HATCHBACK);
  data[2] = new Car("c103",78545.654f,"i10",new Engine(500,330.0f),CarType::SUV);

}

void DeleteObjects(Container &data)
{
  if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
  for(Car* c : data) {
    delete c->engine();  //due to composition rules ;
    delete c;
  }
}

int TotalHorsepower(const Container &data)
{
  if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
  float total = 0.0f;
  for(Car* c : data) {
    total += c->engine()->horsepower();
  }
  return total;
}

bool IsContainerAllCarAbove700000(const Container &data)
{
  if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
  for(Car* c : data) {
    if(c->price() <= 700000.0f){
      return false;
    }
  }
  return true; 
}

Engine *EnginePointerToMinPriceCar(const Container &data)
{
  if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
  //assume the first dtaa value as your min
  float min_price = data[0]->price();
  Engine* e = data[0]->engine();
  for (Car* c : data) {
    if(c->price() < min_price) {
      min_price = c->price();
      e = c->engine();
    }
  }
  return e;
}

float AverageEngineTorque(const Container &data)
{
   if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
  float total_value {0.0f};
  for(Car* c : data){
    total_value += c->engine()-> torque();
  }
  return total_value / data.size();
}

std::string FindCarModelById(const Container &data, const std::string carId)
{
    if(data.empty()) {
    throw EmptyContainerException("Data is empty");
  }
   for(Car* c : data){
    if(c->id() == carId){
        return c->model();
    }
   }
   throw IdNotFoundException("Id not found");
}
