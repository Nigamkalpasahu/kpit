#include <iostream>

/* why enum use ? 
  date : real-value
   wark with categorical data example : months in a year
*/

enum Rank{
    FIRST,
    SECOND,
    THIRD
};
enum Gear{
    FIRST,
    SECOND,
    THIRD
};
enum Position{
    FIRST,
    SECOND,
    THIRD
};
void Magic(int number){
    std::cout<< number * number <<"\n";
}                 
int main(){
    // all three case was giving error in enum class thats why we use enum class over enum
    //we can't force the user to use enum name as a prefix
    enum Rank r1 = Rank::FIRST;
    enum Gear g1 = Gear::FIRST;
// compiler should block conpairision of enum of different types
    if(r1 == g1){
        std::cout<<"OOPS!!!\n";
    }
    //inplicit conversion of enum to int is bad 
    Magic(r1);

}