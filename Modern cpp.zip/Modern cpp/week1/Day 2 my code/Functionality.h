#ifndef FUNCTIONALITY_H
#define FUNCTIONALITY_H

/*
  default & deleted special member function
  override
  member list initialization
  in-class initialization
  for-each(range based for loop)
  enum class
  constructor delegation
*/
#include <array> //STL
#include "Car.h"
using Container = std::array<Car*, 3>;
void CreateObjects(Container& data);
void DeleteObjects(Container& data);

/*  
   input: Container
   output : int
*/
int TotalHorsepower(const Container& data);
/*
is this condition true or false: All cars in the container have a price
above 700000
*/
bool isContainerAllAbove700000(const Container& data);

/*
  return the _engine pointer of the Car whose price is lowest if multiple
  Car instances- have the same minimum, Consider first minimum found
*/

Engine* EnginePointerToMinPriceCar(const Container& data);

// find the average torque for engine in the car container

float AverageEngineTorque(const Container& data);

//Print the model name of the car whose id is passed as a parameter

std::string FindCarModelById(const Container& data, const std::string carId);

/*

*/


#endif // FUNCTIONALITY_H
