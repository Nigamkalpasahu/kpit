/*
const keyword
Rule 1 : Const is applied to the token on its immediate left.
if there is nothing to the left of const, apply const on the token its
immediate right

Rule 2 : pointer symbol * is considered a separate token*/
class dummy
{
private#encapsulation : Hide the internal representation of the object from any party/entity/line of code outside
the class. You can use data binding to achieve this by providing member functions as layer between data 
and the outside world.

#data binding : The concept of relating/binding member function with data membere

                                                              
Abstaraction : Hiding the implementation details of a behaviour(functionality) SO THAT

a) It allows programmers to reimplement a functionality in a duffrent way down the class hierarchy by
overriding in child classes


b) By using abstaraction we can talk in "Abtract" terms while explaining behaviour



scenario 1: I want to model some data. bind members with accessible , perform basic operations  :


   - Create a simple class
   - Bind data members with member functions. keep all data private

scenario 2: I want to Create types and subtypes so that I can generalize operalizes or implement specific
sub catagories


- Create a parent class and appropriate child classes. 
Then, ask the follwing questions

   a) Are all methods implemented in all classes ?
       -If yes, no need for pure virtual functions
   b) Are we going to Create objects of multiple child classesand store them together in the same container
        - if yes , we need to use upcasting
        - Base class methods must be marked as virtual 
        - Destructor must be mark as virtual
   c) Do we need to make the base class abstract/Do we need to prevent installation (object creation for base
   class)
        - make sure atleast 1 method is prent is marked as pure virtual.

   d) I am not bery sure if method will be overriden. may be in future, not sure currently.
        - mark all such methods as virtual 


*/ 
   class A {
    ...
    ...

    public:
        virtual void Display(){
            std::cout<< "A display \n";
        }

        void Test(){
            std::cout << " A test called \n";
        }
   }
    
class B   : public class A{
    ...
    ...

    public:
        virtual  Display() override {
            std::cout<< "B display \n";
        }

        void Test(){
            std::cout << " B test called \n";
        }
   }

   rule 1 : for a class that contains at least 1 virtual method
   A vrtual table is created in memmory, This table has addresses for the 
   virtual methods functions 


   Class A VTable
   [A::Display() :: 0x10045H]
   0x777H
   |
   |
   [vptr]

Rule 2 : if a class inherits from a parent class that also contains a vtable, the child
   will also implement its own vtable  


   A* ptr = new B();
   ptr -> Display();
   //step 1 : verify where is display()
             - go to class whose type is ptr's type
             - go to class and verify this function is at least
             declared is class a
    step 2 : vrify is the method is non-virtual. if yes, call the function
            If function is virtual, proceed to strep 3
    step 3 : Now find the type of RHS (object type). find the vtable for object
            and call fuction based ON entry in vtablek

    a vtable , the child will also implement its own vtable



    /* 
       Assunmption pointer is a parent type;
        1: I want to call fn , fn exist in the parent.
        fn also exists in the child . But fn is non-virtual

        you can use ptr->fn() // this will call parent call fn
        you can use dynamic cast to convert ptr in to child type 
        and then called child::fn

        2: I want to call fn , fn exists in the parent. fn does not existin the child
        fn is non - virtual

        you can use ptr-> Display() // A::fn()
        you should not use dynamic because fn does not exist in the child

        3: I want to call fn , fn exist in the child. fn doesn't exist in thje parent
        fn is non-virtual

        parent pointer is practically useless. you have to do dynamic cast

        4: I want to call fn , fn exist in the parent
        fn also exists in the child . But fn is marked virtual

        compiler will call the most derived version of fn 

        from the inheritance hirrarchy


             Parent
             /      \
            /        \
            child 1   child 2
  
           parent *p = new CHILD2();




// Types of Error

1)  Und#encapsulation : Hide the internal representation of the object from any party/entity/line of code outside
the class. You can use data binding to achieve this by providing member functions as layer between data 
and the outside world.

#data binding : The concept of relating/binding member function with data membere

                                                              
Abstaraction : Hiding the implementation details of a behaviour(functionality) SO THAT

a) It allows programmers to reimplement a functionality in a duffrent way down the class hierarchy by
overriding in child classes


b) By using abstaraction we can talk in "Abtract" terms while explaining behaviour



scenario 1: I want to model some data. bind members with accessible , perform basic operations  :


   - Create a simple class
   - Bind data members with member functions. keep all data private

scenario 2: I want to Create types and subtypes so that I can generalize operalizes or implement specific
sub catagories


- Create a parent class and appropriate child classes. 
Then, ask the follwing questions

   a) Are all methods implemented in all classes ?
       -If yes, no need for pure virtual functions
   b) Are we going to Create objects of multiple child classesand store them together in the same container
        - if yes , we need to use upcasting
        - Base class methods must be marked as virtual 
        - Destructor must be mark as virtual
   c) Do we need to make the base class abstract/Do we need to prevent installation (object creation for base
   class)
        - make sure atleast 1 method is prent is marked as pure virtual.

   d) I am not bery sure if method will be overriden. may be in future, not sure currently.
        - mark all such methods as virtual 


*/ 
   class A {
    ...
    ...

    public:
        virtual void Display(){
            std::cout<< "A display \n";
        }

        void Test(){
            std::cout << " A test called \n";
        }
   }
    
class B   : public class A{
    ...
    ...

    public:
        virtual  Display() override {
            std::cout<< "B display \n";
        }

        void Test(){
            std::cout << " B test called \n";
        }
   }

   rule 1 : for a class that contains at least 1 virtual method
   A vrtual table is created in memmory, This table has addresses for the 
   virtual methods functions 


   Class A VTable
   [A::Display() :: 0x10045H]
   0x777H
   |
   |
   [vptr]

Rule 2 : if a class inherits from a parent class that also contains a vtable, the child
   will also implement its own vtable  


   A* ptr = new B();
   ptr -> Display();
   //step 1 : verify where is display()
             - go to class whose type is ptr's type
             - go to class and verify this function is at least
             declared is class a
    step 2 : vrify is the method is non-virtual. if yes, call the function
            If function is virtual, proceed to strep 3
    step 3 : Now find the type of RHS (object type). find the vtable for object
            and call fuction based ON entry in vtablek

    a vtable , the child will also implement its own vtable



    /* 
       Assunmption pointer is a parent type;
        1: I want to call fn , fn exist in the parent.
        fn also exists in the child . But fn is non-virtual

        you can use ptr->fn() // this will call parent call fn
        you can use dynamic cast to convert ptr in to child type 
        and then called child::fn

        2: I want to call fn , fn exists in the parent. fn does not existin the child
        fn is non - virtual

        you can use ptr-> Display() // A::fn()
        you should not use dynamic because fn does not exist in the child

        3: I want to call fn , fn exist in the child. fn doesn't exist in thje parent
        fn is non-virtual

        parent pointer is practically useless. you have to do dynamic cast

        4: I want to call fn , fn exist in the parent
        fn also exists in the child . But fn is marked virtual

        compiler will call the most derived version of fn 

        from the inheritance hirrarchy


             Parent
             /      \
            /        \
            child 1   child 2
  
           parent *p = new CHILD2();




// Types of Error

1)  Undifined referencxe to <function-name>  - the function defination/implementation does not exist


2) <Identifier> not declare is scope
    - Function name being used doesn't appear in declared symbols
    - variable declared does not appear in avilable names
3) re-defination of class 
    - header guard in not in .h file or same .h file is inluded more that one 

4) two few arguments error 
   - when you call a function with more arguments then requirede or arguments are not in order

5) No matching error - parameter that passed for calling the function that no match with parameter 
in function declaration (its call by value error)


ifined referencxe to <function-name>  - the function defination/implementation does not exist


2) <Identifier> not declare is scope
    - Function name being used doesn't appear in declared symbols
    - variable declared does not appear in avilable names
3) re-defination of class 
    - header guard in not in .h file or same .h file is inluded more that one 

4) two few arguments error 
   - when you call a function with more arguments then requirede or arguments are not in order

5) No matching error - parameter that passed for calling the function that no match with parameter 
in function declaration (its call by value error)


:
    int _id;
    float _salary;
public:
    dummy(int id , float salary): _id{id}, _salary{salary} {}
    ~dummy() = default;

    float salary() const { return _salary; }

     
}; 

#include <iostream>

int main(){
    //scenario 1: const with non-pointer primitive variable
    const int n1 = 10; // n1 is a const int
    int const n2 = 20; // n2 is constant int

    //scenario 2 : pointer with primitive
    int n3 = 99;
    int n4 = 188;
    //2a
    const int * ptr = &n3; //ptr is a pointer to a constant int
    /* *ptr = 77 ;  // this will give error*/
    ptr = &n4; //this is okay

    //2b
    int *const ptr2 = &n3; // ptr2 is a const pointer to an integer
    *ptr2 = 100; // this is okay
    //ptr2 = &n4 //not okay

    //2c
    const int * const ptr3 = &n3; //ptr3 is const pointer to a const integer

    //*ptr3 = 18 // not okay
    //*ptr3 = &n4 // not okay

    //scenario 3 : const on A stack object

    const dummy d1(101 , 67000.08);
    //only a fu8nction that is marked const can be called by a const object

}