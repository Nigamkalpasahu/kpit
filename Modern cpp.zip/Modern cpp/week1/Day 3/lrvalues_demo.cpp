#include <iostream>
#include <vector>
/*
    any form of data that is not preserved
    in a fixes location in memory will disappear
    at the end of the expression (fully expression)
    where it originated
*/

int main(){
    10;  //10: temporary (rvalue);
    "krish";
    std::vector<int> {1,2,3,4};
    // int *ptr = &n1; //lvalues are anything which are the names given by the user amd memory location 
}