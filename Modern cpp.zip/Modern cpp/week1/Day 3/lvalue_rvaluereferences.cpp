#include <iostream>
#include <list>

void Magic(std::list<int>& data){

}

/*
    1) WeiredMagic function can only be called by an rvalue
        - It means the user will never be able 
            to copies of data.
            One in caller(Main) function 
            and one in callee(WeirdMagic)
*/

void WeirdMagic(std::list<int>&& data){     //&& rvalues references  MODERN C++
    std::cout<<data.size()<<"\n";

}

int main(){
    std::list<int> l1 {1,2,3,4,5};  //lvalue
    // Magic(l1);  //call by lvalue reference
    WeirdMagic(std::list<int>  {1,2,3,4,5});    //rvalue reference

}