#include <iostream>
#include <vector>


/*
    Magic is a function that accepts 1 stud vector
    of integers by value Magic returns void
*/
void Magic(std::vector<int> data){  
    std::cout<<data.size()<<"\n";
}


int main(){
    std::vector<int> v1 {10,20,30};    //lvalue reference

    Magic( std::vector<int> {1,2,3,4,5});  //rvalue reference
    Magic(v1);   //lvalue reference------>rvalue reference
    // Magic(std::move(v1)); if we want to run this then add 
}

/*
    std::vector<int> data  =   std::vector<int> {1,2,3,4,5}       
*/