#include <iostream>
/*
   for each loop
   for loop using begin & end iterator
   return type of a function
   lambda variable type
   function parameter with auto
   template parameter for lambda(cpp 14)
   auto&& in for loop


   best practice
   a) don't use auto when you have no idea what exactly will be replaced in place of auto
   b) always verify wheather auto can be used where you are using it (context)
   Magic(auto n1){

   }
*/
#include<vector>
int main(){
    auto n1 = 10 ; // agar value metione ha tabhi auto key word chalega
    std::vector<int> v1 {1,2,3,4,5};
    auto itr = v1.begin();

    decltype(v1) v2{1,2,3,4,5}; // v1 type is copy to v2
    

}