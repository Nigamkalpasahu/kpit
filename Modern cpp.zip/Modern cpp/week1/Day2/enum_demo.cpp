#include <iostream>
void Magic(int _number){
  std::cout<< _number * _number << std::endl;
}
enum class Rank {
  FIRST,
  SECOND,
  THIRD
};
enum class Gear {
  FIRST,
  SECOND,
  THIRD
};
enum class Position {
  FIRST,
  SECOND,    
  THIRD
};

int main() {
  enum Rank r1 = Rank::FIRST;
  enum Gear g1 = Gear::FIRST;
  if (r1 == g1) {
    std::cout << "OOPS !!\n";
  }
  //implicit conversion is allowed in enum and not in enum class
  Magic(r1);
}