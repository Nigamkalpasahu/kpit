#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "Car.h"
#include <array> //STL wala
#include <memory>

//using CarPoint er = std::shared_ptr<Car>;

//instead of typedef use "using" keyword
                                                                                   
                                                                                    
using Container = std::array<Car*,3>;

void CreateObjects(Container& data);
void DeleteObjects(const Container& data);

int TotalHorsepower(const Container& data);

//Is this condition true or false : All cars in the container have a price above 700000
bool IsContainerAllCarAbove700000(const Container& data);
/*
  return the _engine pointer of the Car whose price is lowest.
  If multiple car instances have the same minimum, consider first minimum found.
*/

Engine* EnginePointerToMinPriceCar(const Container& data);

//  find the average torque for engines in the car container.

float AverageEngineTorque(const Container& data);

// Print the model name of the car whose id is passed as a parameter.

std::string FindCarModelById(const Container& data, const std::string carId);


#endif // FUNCTIONALITIES_H
