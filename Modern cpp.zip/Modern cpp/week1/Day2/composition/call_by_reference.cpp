#include <iostream>

/*    
    int &a = reference
    &a : no data type to the left of a : address(pointer)
*/

void Magic(int &value){
    std::cout << "value in magic before modification is: "<< value << "\n";    
    std::cout << "address of value inside magic  is: "<< &value << "\n";

    value = 111;
    std::cout << "  value is  magic after modification is: "<< value << "\n";
}
int main(){
    int value = 100;
    std::cout<<"value in main before modification "<<value<<"\n";
    std::cout<< "Adress of value inside the main is " << &value <<"\n";
    Magic(value);
    std::cout<< "Value is main after magic  "<<value <<"\n";

}