#ifndef CARTYPE_H
#define CARTYPE_H

/*enum is used when we have categorical data. 
Example of categorical data : months in a yr, i.e 1 - 12 
In modern c++ use enum class in place of enum*/

enum class CarType {
  SEDAN,
  SUV,
  HATCHBACK
};

#endif // CARTYPE_H
