/*
    A situation where only one element needs to be accessed and it is the most
    recen item inserted in to the container

    e.g : A compiler executing fuctions calls 

    f1(){
        f2()
    }

    call stack

    f2----- recently added , top most entry , will be accessed first

    f1----- still pending

    -> iterators(for , for each) can't work on stack
*/

#include<stack>
#include"Employee.h"
#include<function.h>

using Container = std::stack<Employee>;

int main(){
    Container s1 ;
    s1.push(Employee("Nigam" , 788789.0f , "Trainer" , 10));
}







