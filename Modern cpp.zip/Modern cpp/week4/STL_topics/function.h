#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Employee.h"
#include <memory>
#include <algorithm>
#include<numeric>
#include<iostream>

using EmployeeContainer = std::vector < Employee>;
using EmployeePointerContainer = std::vector < Employee*>;
using EmpSptr = std::shared_ptr < Employee>;
using EmployeeSmartPointerContainer = std::vector < EmpSptr>;

void CreateEmployees(EmployeeContainer& data){
    data.push_back(
        Employee("Krish" , 80000.0f , "Developer" , 2));
    data.push_back(
        Employee("Vishal" , 80000.0f , "Trainer" , 12));
    data.push_back(
        Employee("Abhinav" , 80000.0f , "Tester" , 2));
}

void CreateEmployeePointers(EmployeePointerContainer& data){
    data.push_back(
        new Employee("Krish" , 80000.0f , "Developer" , 2));
    data.push_back(
        new Employee("Vishal" , 80000.0f , "Trainer" , 12));
    data.push_back(
        new Employee("Abhinav" , 80000.0f , "Tester" , 2));
}
void CreateEmployeeSmartPointer(EmployeeSmartPointerContainer& data){
    data.push_back(
        std::make_shared<Employee>("Krish" , 80000.0f , "Developer" , 2));
    data.push_back(
        std::make_shared<Employee>("Vishal" , 80000.0f , "Trainer" , 12));
    data.push_back(
        std::make_shared<Employee>("Abhinav" , 80000.0f , "Tester" , 2));
}

#endif // FUNCTIONALITIES_H
