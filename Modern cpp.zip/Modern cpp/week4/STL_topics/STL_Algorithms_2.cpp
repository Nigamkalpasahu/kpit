#include "function.h"
#include <algorithm>
#include<numeric>
#include <vector>
#include <iostream>
#include <functional>


template <typename T , typename P >
auto Search(

    const T data,
    const P fn
    // const EmployeeContainer& data , 
    // const std::function<bool(const Employee&)> fn
){

   auto itr = std::find_if(
    data.begin(),
    data.end(),
    [](const Employee& emp){
        return emp.designation() = "Trainer";});

    if(itr ==data.end()){
        std::cerr << "Object not found\n";
        return itr;
    }else{
        std::cout<<"Object Found: " ;
        return itr;
    }

}



int main(){
    EmployeeContainer data1;
    EmployeePointerContainer data2;
    EmployeeSmartPointerContainer data3;

    CreateEmployees(data1);
    CreateEmployeePointers(data2);
    CreateEmployeeSmartPointer(data3);
    /////////////////////////////////////////////////////////////////////////////////

    /*
        std::find_if
            std::find_if returns "iterator to the FIRST MATCHING OBJECT"
            If matchi is not found, find _if return end iterator 
    */


    auto itr = 
    Search<EmployeeContainer , std::function<bool(const Employee&) >>(
        data1, 
        [](const Employee& emp){
        return emp.salary() > 40000.0f;
    });


    std::find_if(
        data3.begin(),
        data3.end(),
        [](const EmpSptr& emp){return emp->salary() > 40000.0f;}
    );

}