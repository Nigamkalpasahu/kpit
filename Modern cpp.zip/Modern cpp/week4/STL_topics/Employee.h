#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>
class Employee
{
private:
    std::string _name;
    float _salary;
    std::string _designation;
    int _exp_years;
public:
    Employee(std::string name, float salary , std::string designation, int years)
    : _name{name}, _salary{salary} , _designation{designation} , _exp_years{years}
     {}

  Employee() = default; //default constructor enabled
  Employee(const Employee&) = default; // copy constructor disabled
  Employee(Employee&&) = default; //disabled move constructor, c++ brand new
  Employee& operator=(const Employee&) = default; //deleted copy assignment operator 
  Employee& operator=(Employee&&) = default; // deleted move assignment operator, c++ brand new
  ~Employee() = default; // default destructor enabled

  std::string name() const { return _name; }

  float salary() const { return _salary; }

  std::string designation() const { return _designation; }
  int expYears() const { return _exp_years; }

  void setName(const std::string &name) { _name = name; }

  void setSalary(float salary) { _salary = salary; }

  void setDesignation(const std::string &designation) { _designation = designation; }

  void setExpYears(int exp_years) { _exp_years = exp_years; }

  friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);
 };

inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_name: " << rhs._name
       << " _salary: " << rhs._salary
       << " _designation: " << rhs._designation
       << " _exp_years: " << rhs._exp_years;
    return os;
}

#endif // EMPLOYEE_H
