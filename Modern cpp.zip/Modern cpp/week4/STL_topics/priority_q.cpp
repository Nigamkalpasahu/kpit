 
    // bool operator(){

    // }
     
  //
#include <iostream>
#include <queue>
#include <vector>
#include <functional>
#include "Employee.h"

struct Less_Comparator{
    bool   operator()(int a, int b){
        return a > b;
    };
};


int main(){
    std::vector
    <int> data {11,10,22,7,9,15,27,18};
    std::priority_queue<int,std::vector<int>, std::greater<int>> pq (data.begin(),data.end());
    while(!pq.empty()){
        std::cout << "Popping : " << std::endl;
        pq.pop();
    }

    auto comp = [](const Employee& e1, const Employee& e2){
        return e1.expYears() < e2.expYears();
    };
    // Note : if using lambda as comparator , also lambda object as a parameter
    //to constructor of priority queue
    std::priority_queue<Employee,std::vector<Employee>, decltype(comp)> pq2 (comp);
    
}               
            