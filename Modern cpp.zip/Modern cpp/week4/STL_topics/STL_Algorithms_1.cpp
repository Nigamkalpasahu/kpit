 /*
    How to use STL algorithms effectively!

    1) std::count_if
      count instances mathich with
*/

#include  "function.h"
#include "Employee.h"
#include <memory>
#include <algorithm>
#include<numeric>
#include<iostream>



int main(){
    EmployeeContainer data1;
    EmployeePointerContainer data2;
    EmployeeSmartPointerContainer data3;
    

    CreateEmployees( data1);
    CreateEmployeePointers(data2);
    CreateEmployeeSmartPointer(data3);


    // count instances matching

    int count =  std::count_if(
        data1.begin(),
        data1.end(),
        [](const Employee emp) {return emp.salary() > 40000.0f; }
    );


    std::cout<< std::count_if(
        data2.begin(),
        data2.end(),
        [](const Employee* emp) {return emp->salary() > 40000.0f; }
        
    );

    std::cout<< std::count_if(
        data3.begin(),
        data3.end(),
        [](const EmpSptr& emp) {return emp->salary() > 40000.0f; }
    );

}