/*
    smart pointer : they are wrappers- around raw pointers to allow better memory
    management using RAII design pattern

     1) shared_pointer  
     2) unique_pointer
     3) weak pointer : stalker pointer [shared pointer --->token ]
*/

#include <iostream>        
#include <memory>             
#include <thread>
#include "/home/kpit/Desktop/Modern cpp/week4/STL_topics/Employee.h"
std::shared_ptr<Employee> sptr;

 void Magic(std::shared_ptr<Employee> owner2){
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout << *owner2 << "\n";
 }

 int main(){
    sptr = std::make_shared<Employee>
    ("Nigam" , 5670.0f , "TraIner" , 10);
    Magic(std::move(sptr));

    std::weak_ptr<Employee>wkptr = sptr;
    
    if(wkptr.lock()){
        std::cout<< "Tiger zinda ha";
    }
    else{
        std::cout<< "margaya **** ";
    }
    sptr.reset();
    std::this_thread::sleep_for(std::chrono::seconds(1));

    if(wkptr.lock()){
        std::cout<< "Tiger zinda ha";
    }
    else{
        std::cout<< "margaya **** ";
    }
 }