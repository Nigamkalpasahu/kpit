/*
    smart pointer : they are wrappers- around raw pointers to allow better memory
    management using RAII design pattern

     1) shared_pointer
     2) unique_pointer 
     3) weak pointer : stalker pointer [shared pointer --->token ]
*/

#include <iostream>
#include <memory>
#include <mutex>
#include <thread>
#include "/home/kpit/Desktop/Modern cpp/week4/STL_topics/Employee.h"

std::mutex mt;
bool allThreadsDone = false;

void ChangeName(std::shared_ptr<Employee>& owner2){
    owner2->setName("MSN");
    std::cout << *owner2 << std::endl;
}        

void UpdateSalary(std::shared_ptr<Employee>& owner3) {
    owner3->setSalary(2434.23f);
    std::cout << *owner3 << std::endl;
}

int main() {
    //std::shared_ptr<int[]> ptr1 = std::make_shared<int[]>(new int);

    std::shared_ptr<Employee> ptr=std::make_shared<Employee>("Aditya",1234.56f,"Trainee",1);
    
    std::thread t1(&ChangeName, ptr);
    std::thread t2(&UpdateSalary, ptr);

    t1.join();
    t2.join();

    allThreadsDone = true;
    
    if(std::lock_guard<std::mutex> lg(mt); !allThreadsDone) {
        std::cout << *ptr << std::endl;
    }
        
}