/*
    _id
    _username
    static counter
    disable all special member except destructor
    << out operator
    RegisterAccount() = 0
*/

#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <iostream>

class Account
{
private:
     static unsigned long _counter;
     std::string _username;
     unsigned long _user;
public:
    Account() = delete;
    Account(const Account&) = delete;
    Account& operator=(const Account&) = delete;
    Account&& operator=(Account&&) = delete;
    Account(Account&&) = delete;
    ~Account() = default;

    std::string username() const { return _username; }
    void setUsername(const std::string &username) { _username = username; }

    unsigned long user() const { return _user; }

    friend std::ostream &operator<<(std::ostream &os, const Account &rhs);

    
};

#endif // ACCOUNT_H
