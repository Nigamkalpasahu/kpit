#include "Account.h"
#include<iostream>

unsigned long Account::_counter = 90000;


std::ostream &operator<<(std::ostream &os, const Account &rhs) {
    os << "_username: " << rhs._username
       << " _user: " << rhs._user;
    return os;
}
