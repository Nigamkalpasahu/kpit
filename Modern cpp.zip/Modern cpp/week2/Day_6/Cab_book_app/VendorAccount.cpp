#include "Vendor.h"


std::ostream &operator<<(std::ostream &os, const VendorAccount &rhs) {
    os << static_cast<const Account &>(rhs)
       << " _venderName: " << rhs._venderName;
    return os;
}
