#ifndef FEATURES_H
#define FEATURES_H



class Features
{
private:
    /* data */
public:
    Features(/* args */) {}
    ~Features() {}
};
/*
    should accept refernce of a container
    an enum to decide type of account
    then accept input , cell the constructor and store pointer
    in acountContainer
*/

#endif // FEATURES_H
