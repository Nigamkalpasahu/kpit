#ifndef CUSTOMER_H
#define CUSTOMER_H

#include"Gender.h"

#include<iostream>

class CustomerAccount
{
private:
    std::string _fullName;
    Gender _customerType;
public:
    CustomerAccount() = delete;
    CustomerAccount(const CustomerAccount&) = delete;
    CustomerAccount& operator=(const CustomerAccount&) = delete;
    CustomerAccount&& operator=(CustomerAccount&&) = delete;
    CustomerAccount(CustomerAccount&&) = delete;
    ~CustomerAccount() = default;
};

#endif // CUSTOMER_H
