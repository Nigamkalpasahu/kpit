#ifndef VENDOR_H
#define VENDOR_H

#include "Account.h"
#include <ostream>
#include <vector>

class VendorAccount : public Account
{
private:
    std::string _venderName;
    std::vector<Driver>> _driver& {};//
public:
    VendorAccount() = delete;
    VendorAccount(const VendorAccount&) = delete;
    VendorAccount& operator=(const VendorAccount&) = delete;
    VendorAccount&& operator=(VendorAccount&&) = delete;
    VendorAccount(VendorAccount&&) = delete;
    ~VendorAccount() = default;

    friend std::ostream &operator<<(std::ostream &os, const VendorAccount &rhs);

    VendorAccount( std::string username,std::string _venderName);
};

#endif // VENDOR_H
