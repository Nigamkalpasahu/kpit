#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Employee.h"
#include "Project.h"
//#include <iostream>

void CreateObjects(Employee* employee, Project* projects);

void CreateObjects(std::vector<Employee>& , Project* projects);


#endif // FUNCTIONALITIES_H
