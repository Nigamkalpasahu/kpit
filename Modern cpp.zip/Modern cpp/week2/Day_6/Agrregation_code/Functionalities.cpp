#include "Functionalities.h"

    void CreateObjects(Employee **employees , Project *projects){
        projects[0] = new Project("pr101", 6670.0f, 11);
        employees[0] = new Employee("emp101" , "Nigam" , 36000.0f , *projects[0]);
    }