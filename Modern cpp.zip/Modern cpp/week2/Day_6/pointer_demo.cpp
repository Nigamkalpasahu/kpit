/*
    A pointer is an address of somthing
*/
#include<iostream>

/*
    use case 1 : make an array
*/
struct Employee
{
    int _id;
    int _salary;
    Employee(int id , float salary): _id{id} , _salary{salary}{}
    ~Employee() {}
};
 



void Magic(Employee** arr){

}

void F1(){
    int arr[] = {10, 20 , 30};
    //int *ptr = arr; // attach with array 1st location
 
    Employee*  e1 = new Employee(10 , 10000.0f);
    Employee* e2 = new Employee(20 , 20000.0f);
    Employee* arr[2] = {e1 , e2};
    Magic(arr);


}