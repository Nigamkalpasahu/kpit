#include <iostream>

/*
    system which accept data value and "logic" This logic
    will be applied an every single data value received output will shown

    fn(data, logic)
*/

void square(int number){
    std::cout << "square of : " << number << " is: " << number*number << '\n';

}

void cube(int number){
    std::cout << "cube of : " << number << " is: " << number*number*number << '\n';

}

//operation is a higher function
//accept or returns (or both) another function
void Operation(int* arr, int size, void (*ptr) (int) ){
    for(int i = 0; i< size ; i++){
        (*ptr)(arr[i]);
    }
}



int main(){
    //function  pointer call
    // void (*ptr) (int) = square;
    // void  (*ptr2)(int) = cube;
    int arr[5] = {10 , 20 , 30 , 40 , 50 };
    Operation(arr , 5 , square) ;

}


/*
    Higher order function
    Ananymous fuction
    functional programming paradime
    no state
    immutable data
    currying
    first-class function
*/