#include <iostream>
/*
    NO. Identifier - Name  Adress content alternate names
    1     n1          
*/

void Magic(int& argRef){

}

int main(){
    int n1 = 99;
    int& ref = n1;
    Magic(n1);// pass by reference
    /*
        a reference doesn't exist anywhere in memory
        so the canot be treated like value

        previously 
               A pointer when stored internally in an object
               creates representation of a pointer (smart pointer)

               A reference stored in an object internally create
               representation of a reference called reference wrapper
    */
   //int arr[] = {ref};// giving error

}