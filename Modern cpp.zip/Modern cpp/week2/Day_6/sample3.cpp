 #include <iostream>
#include <functional>

void Cube(int n){
    std::cout << "Cube of " << n << " is: " << n*n*n << std::endl;
}

void Operation(const std::vector<int>& data, std::function<void(int)> fn){
    for (int val : data) {
        fn(val);
    }
    
}

int main() {    
    std::vector<int> data {1,2,3,4,5};

    // this is lambada function
    // auto f1 = [](int n) -> void {
    //     std::cout << "Square of " << n << " is: " << n*n << std::endl;
    // };
    // //Operation(data, Cube);
    // Operation(data, f1);

      //another way of wriiten lambda function
      // this is more efficient way from before declaration
      Operation(data,
     [](int n) -> void /*if you want you just not give the return type*/ { 
          std::cout << "Square of " << n << " is: " << n*n << std::endl;
      });
      //Operation(data, Cube);

}
