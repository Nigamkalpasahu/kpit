 #include <iostream>

 class LambdaImplementation {
    private:
      int _number;// to be discussed
    public:
       LambdaImplementation() = default;
       ~LambdaImplementation() = default;

     //function call () operator [paren paren]
       void operator()(int n)  { 
          std::cout << "Square of " << n << " is: " << n*n << std::endl;
      };
 };

 int main(){
    LambdaImplementation l1;
    l1(10); // operator () is called
 }