#include <iostream>
#include<functional>
#include<array>

/*
    Objective :
       Design an adaptor function that accepetes
       a container of function wrappers and a container of data values
       Map each function on each item in the data container and print
       the output

       # All function must accept only on integer and return void 
*/
using Fntype = std::function<void(int)>;
using DataContainer = std::array<int , 5>;
using FnContainer = std::array<Fntype , 3>;

void Adaptor(const FnContainer& fns, const DataContainer& data){
    // loop over fns
    // nested loop over data , apply fn on data
    for(const Fntype fn :fns){
        for(int val : data){
            fn(val);
        }
    }
}
 
int main(){
    FnContainer fns {
        [](int number) {std::cout <<number * 10;},
        [](int number) {std::cout <<number * number;},
        [](int number) {std::cout <<number * number * number;},

    };
    Adaptor(
        fns,
        std::array<int , 5> {1 , 2 , 3, 4 , 5}
    );
}