#include <iostream>
#include <functional>
#include <list> 
#include<cstring> 
//bind : 

//ashishrawat@kpit.com
/*
    Problems in software industry:
    1. we cant massively change code after it is deployed for client.
    2. sometimes API parameters need to be fixed at a certain value.
*/

void Formula(const int x, const int y, const int z){
    std::cout << "Answer is: " << ((x+y)-z) << std::endl;
}

void Magic(const std::list<int>& data, int n){
    for(int val : data){
        n--;
        if(n==0){
            std::cout << val << std::endl;
        }
    }
}

int main() {
    Formula(10,20,30); //x=10,y=20,z=30
    auto binded_formula = std::bind(&Formula,100,std::placeholders::_1,std::placeholders::_2);
    binded_formula(30,40); // x=100,y=30,z=40
    binded_formula(30, 40 , 50); // x=100,y=30,z=40


    auto binded_Magic = std::bind(&Magic, std::placeholders::_2 , std::placeholders::_1);
    auto binded_strcpy = std::bind(&strcpy, std::placeholders::_2, std::placeholders::_1);
    // char*msg;
    // binded_strcpy("Nigam" , msg);
    auto fn = [](int number, int factor){ std::cout<< number *factor; };
    // a lambda is an object , using & on a lambda meanstaking address of object,
    //Don't use & sign with lambda in bind
    auto binded_lambda_fn = std::bind(fn , std::placeholders::_1 , 40);

    binded_lambda_fn(100); // fn(100 , 40)
    binded_lambda_fn(100 , 20); //fn(100, 40)
 
}


/*
    void Magic(const int n1 , std::string& name);
    std::function<void (const int, std::string&)> fn = &Magic

    fn = &Magic

    auto f1 = []() {std::cout <<"hello";};
    

*/


/*
    void Magic(){
        std::cout << "hello\n"; 
        int n1 = 10; 
        std::cout <<n1 * 90;
    }

    std::function <void () > fn = Magic
    //please take the address of first instruction of magic and give it to fn
    fn
*/