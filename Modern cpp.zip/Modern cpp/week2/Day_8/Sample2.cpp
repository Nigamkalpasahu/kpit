#include <iostream> 
#include<functional>

class Action
{
private:
    int _id;
public:
    Action() = default; 
    ~Action() = default;
    void Operation(int number) {std::cout << _id *10;}
};

int main(){
    Action a1;
    auto binded_operation = std::bind(&Action::Operation , &a1 ,  40);
// a non static member function of class we have to ruse & percent before the member function 
// and its mendatory
    binded_operation(); // a1.operation(40);
}