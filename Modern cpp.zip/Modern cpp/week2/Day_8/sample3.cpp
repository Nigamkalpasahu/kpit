/*
    week 2 :
    Function pointers
    Function wrapper
        - a way to capture any callable in a
          type-erased way
        - It can be used for following
          - pass a colable as a parameter
          - Return a colable as a value
          - save function as "values" in container/ variables
    reference wrapper
       - It is an object that internally stores
       reference to "something"
       - It uses pointer to reference conversion internally
       - It can be replacement for raw reference overwhere in the code
       - R value cannot be coverted to reference wrapper .

    std::bind
       - used to create a partial function
         - a function some parameters are already fixed
        - redesign or tweak the squence of parameters by swapping or repositioning
        them as per requirement

*/
#include<iostream>
#include<functional>

int& Magic(){
   int n1 = 10;
    return n1;
}

int main(){
    std::reference_wrapper<int> ref(Magic());
    std::cout<<ref.get() <<"\n";
}

/*

*/