#include <iostream>
#include <vector>
#include <memory>
#include <functional>
class Employee
{
private:
    int _id;
    std::string _name;
    float _salary;
public:
    Employee() = default;
    Employee(const Employee&) = delete;
    Employee(const Employee&&) = delete;
    Employee operator=(const Employee&) = delete;
    Employee operator=(const Employee&&) = delete;
    ~Employee() = default;
    Employee(int id, std::string name, float salary) : _id{id}, _name{name}, _salary{salary}{}

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
        os << "_id: " << rhs._id
           << " _name: " << rhs._name
           << " _salary: " << rhs._salary;
        return os;
    }
    
    float operator+(const Employee& rhs){
        return _salary + rhs._salary;
    }

    float operator-(const Employee& rhs){
        return _salary - rhs._salary;
    }

    void operator()() {
        std::cout << "Tax for this employee at 10% is :" << _salary*0.1f << std::endl;
    }

    float salary() const { return _salary; }
};

/*
    Objective : take a container of raw pointers to Employee and filter and print details
    based on predicate passed.
*/

void Adaptor(const std::vector<Employee*>& data,std::function<bool(Employee*)> predicate){
    for(Employee* ptr : data){
        if(predicate(ptr)){std::cout << *ptr << std::endl;}
    }
}
//shared pointer
 using EmployeePointer = std::shared_ptr<Employee>;

void Adaptor(
    const std::vector<EmployeePointer>& data,
    std::function<bool(EmployeePointer)> predicate){
    for(EmployeePointer ptr : data){
        if(predicate(ptr))
        {
            std::cout << *ptr << std::endl;
            }
    }
}

int main() {
    std::vector<Employee*> data {
        new Employee(01,"Uno",23232.23f),
        new Employee(02,"Dos",343434.343f)
    };
    //find all employee whose salary is above 8000
    Adaptor(data,[](Employee* emp){
        if(emp){
            return emp->salary() > 80000.0f;
        } else {
            return false;
        }
    });
// shared pointer
    std::vector<EmployeePointer> data2 {
        std::make_shared< Employee>(01,"Uno",23232.23f),
        std::make_shared< Employee>(02,"Dos",343434.343f)
    };

    Adaptor(
        data2 ,
    [](EmployeePointer emp){
        if(emp){
            return emp->salary() > 80000.0f;
        } else {
            return false;
        }
    });
}
 