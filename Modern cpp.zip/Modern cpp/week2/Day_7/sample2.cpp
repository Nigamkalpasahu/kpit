
#include<iostream>
#include<functional>

/*
    objective : Create an adapted which takes
    1) A callable of the following signature
      input: int and int
      output void
    2) INTEGER number n1

    3)  INTEGER number n2

    The adpatop must apply/map the callable on the 2) and 3) integers
*/
/*
    honda : login --> "something must happen after successful login"
*/
// void addition( int n1 , int n2){
//     std::cout<< n1 + n2;
// }

/*
    Adaptor is a higher order function that accepts 
    a) a function wrapper for all functions that have the following- signature
       1) int , int input parameter
       2) void as return type

    and 2 integer by value
*/
void Adaptor( std::function<void(int , int )> fn   , int n1 , int n2 ){
     fn( n1, n2);
}
int main(){
    Adaptor(
        [](int n1, int n2) {std::cout<< n1 * n2<<std::endl;},
        11,
        22
    );

     Adaptor(
        [](int n1, int n2) {std::cout << n1 - n2<<std::endl;},
        11,
        22
    );
}