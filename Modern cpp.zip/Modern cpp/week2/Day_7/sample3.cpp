/*
    objective : Design an adaptor to accept
      a vector of intergers
      a predicate (a function that returns true or false based an a single input )
      
      Use the predicate to print data from vector
*/
// predicate is fun with one argument which return only boolean value(true , false ) according its task
#include<iostream>
#include<functional>
#include<vector>
void Adaptor (std::function <bool (int)> predicate, const std::vector<int>& data){
    for(int val : data){
        if(predicate(val)){std::cout<<val<<std::endl; }
    }
}
int main(){
    Adaptor(
        [](int n){return n % 5 == 0; },
        std::vector<int> {10, 20, 40, 30, 50}
    );

     Adaptor(
        [](int n){return n % 5 ==0 && n % 3 == 0 ; },
        std::vector<int> {10, 20, 40, 30, 50}
    );
}