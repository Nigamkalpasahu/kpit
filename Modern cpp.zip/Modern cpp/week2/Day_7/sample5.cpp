/*
    trigger app
    f1-----> f2(2 integers will be created)
    |
    |
    |
    |
        predicate to filter the data
*/
#include<iostream>

void f2(int n1 , int n2){
    /*
        A lambda can capture data from its enclosing function without
        explicit passing
    */
     auto lambda_fn = [ & ]() {return n1 + n2 ;};
     lambda_fn();
}

void f1(){
    int n1 = 10;
    int n2 = 20;
    f2(n1 , n1);
}

int main(){
    f1();
}
/*
    Main fn stack memory

    f1 stack memory
    n1       n2
               [20]
    
    f3 stack memory

    void Magic(){
        int n1 = 10 , n2 = 20 , n3 = 30;
        example1 : all data values from "enclosing function "
        are accesssible inside f1
        auto f1 = []
    }
*/
void trick(){
    int n1 = 100;
    auto f1 = [=] ()mutable {n1 = 99; };
    std::cout<< n1 << "\n";
}