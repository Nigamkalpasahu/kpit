 #include "Automobile.h"

Automobile::Automobile(const std::string& model_name, const std::string& automobile_type, float automobile_price, float automobile_mileage)
    : _model_name(model_name), _automobile_type(automobile_type), _automobile_price(automobile_price), _automobile_mileage(automobile_mileage) {}

std::string Automobile::getModelName() const {
    return _model_name;
}

std::string Automobile::getAutomobileType() const {
    return _automobile_type;
}

float Automobile::getAutomobilePrice() const {
    return _automobile_price;
}

float Automobile::getAutomobileMileage() const {
    return _automobile_mileage;
}
