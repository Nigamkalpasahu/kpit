#include "Automobile.h"
#include <vector>
#include <memory>
#include <iostream>

// Function to create objects of the class Automobile on the heap
std::vector<std::unique_ptr<Automobile>> createObjects() {
    std::vector<std::unique_ptr<Automobile>> automobiles;
    automobiles.push_back(std::make_unique<Automobile>("Model1", "private", 15000.0, 20.0));
    automobiles.push_back(std::make_unique<Automobile>("Model2", "Transport", 25000.0, 15.0));
    automobiles.push_back(std::make_unique<Automobile>("Model3", "private", 18000.0, 18.0));
    automobiles.push_back(std::make_unique<Automobile>("Model4", "Transport", 30000.0, 12.0));
    return automobiles;
}

// Function to return the average mileage of all instances
float averageMileage(const std::vector<std::unique_ptr<Automobile>>& automobiles) {
    float totalMileage = 0;
    for (const auto& auto_ptr : automobiles) {
        totalMileage += auto_ptr->getAutomobileMileage();
    }
    return totalMileage / automobiles.size();
}

// Function to count the number of instances whose _automobile_type matches the given type
int countByType(const std::vector<std::unique_ptr<Automobile>>& automobiles, const std::string& type) {
    int count = 0;
    for (const auto& auto_ptr : automobiles) {
        if (auto_ptr->getAutomobileType() == type) {
            count++;
        }
    }
    return count;
}

// Function to check if at least one instance has a _automobile_price above 20000
bool hasPriceAbove(const std::vector<std::unique_ptr<Automobile>>& automobiles, float priceThreshold) {
    for (const auto& auto_ptr : automobiles) {
        if (auto_ptr->getAutomobilePrice() > priceThreshold) {
            return true;
        }
    }
    return false;
}

// Function to destroy (deallocate) objects if allocations are managed using raw pointers
void destroyObjects(std::vector<std::unique_ptr<Automobile>>& automobiles) {
    automobiles.clear(); // Destroying unique pointers, automatically deallocates memory
}
