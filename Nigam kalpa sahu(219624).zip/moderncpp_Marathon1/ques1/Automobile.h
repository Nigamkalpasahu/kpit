#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include <string>

class Automobile {
private:
    std::string _model_name;
    std::string _automobile_type;
    float _automobile_price;
    float _automobile_mileage;

public:
    Automobile(const std::string& model_name, const std::string& automobile_type, float automobile_price, float automobile_mileage);
    Automobile(const Automobile& other) = delete;
    Automobile& operator=(const Automobile& other) = delete;
    Automobile(Automobile&& other) = delete;
    Automobile& operator=(Automobile&& other) = delete;

    std::string getModelName() const;
    std::string getAutomobileType() const;
    float getAutomobilePrice() const;
    float getAutomobileMileage() const;
};

#endif // AUTOMOBILE_H
