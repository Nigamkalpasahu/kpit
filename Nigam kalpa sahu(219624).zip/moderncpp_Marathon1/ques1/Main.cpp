#include "functionalities.cpp" // Include the functionalities from the functionalities.cpp file
#include <iostream>
#include <stdexcept> // Include for exception handling

int main() {
    try {
        auto automobiles = createObjects();

        std::cout << "Average Mileage: " << averageMileage(automobiles) << std::endl;
        std::cout << "Number of private automobiles: " << countByType(automobiles, "private") << std::endl;
        std::cout << "Price above 20000: " << std::boolalpha << hasPriceAbove(automobiles, 20000.0) << std::endl;

        destroyObjects(automobiles);
    } catch (const std::exception& e) { 
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
