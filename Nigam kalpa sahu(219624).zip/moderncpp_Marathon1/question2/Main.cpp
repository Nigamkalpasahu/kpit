#include "functionalities.h"
#include <iostream>
#include <stdexcept>

int main() {
    try {
        // Create employees
        auto employees = createEmployees();

        // Display count of instances with _project_budget over 5000.0f
        std::cout << "Count of instances with project budget over 5000.0f: " << countHighBudgetProjects(employees) << std::endl;

        // Check if all employees have salary above 10000.0f
        std::cout << "All employees have salary above 10000.0f: " << std::boolalpha << allEmployeesAboveSalary(employees) << std::endl;

        // Calculate average tax exemption
        std::cout << "Average Tax Exemption: " << averageTaxExemption(employees) << std::endl;

        // Display details of first N instances
        int N = 2;
        std::cout << "Details of first " << N << " instances:" << std::endl;
        displayNProjectInstances(employees, N);

        // Destroy employees
        destroyEmployees(employees);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    return 0;
}
 