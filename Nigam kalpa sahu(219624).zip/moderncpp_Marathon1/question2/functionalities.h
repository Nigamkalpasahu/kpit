#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include <memory>

class Employee;
class Project;

std::vector<std::unique_ptr<Employee>> createEmployees();

int countHighBudgetProjects(const std::vector<std::unique_ptr<Employee>>& employees);

bool allEmployeesAboveSalary(const std::vector<std::unique_ptr<Employee>>& employees);

float averageTaxExemption(const std::vector<std::unique_ptr<Employee>>& employees);

void displayNProjectInstances(const std::vector<std::unique_ptr<Employee>>& employees, int n);

void destroyEmployees(std::vector<std::unique_ptr<Employee>>& employees);

 

#endif // FUNCTIONALITIES_H
