#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>

class Project; // Forward declaration

class Employee {
private:
    std::string _employee_id;
    std::string _employee_name;
    float _salary;
    Project* _project; // Pointer to Project instance

public:
    Employee(std::string employee_id, std::string employee_name, float salary, Project* project = nullptr);
    Employee(const Employee&) = delete; // Disable copy constructor
    Employee& operator=(const Employee&) = delete; // Disable copy assignment operator
    Employee(Employee&&) = delete; // Disable move constructor
    Employee& operator=(Employee&&) = delete; // Disable move assignment operator

    float TextExemptionAmount() const;

    // Destructor
    ~Employee();
};

#endif // EMPLOYEE_H
