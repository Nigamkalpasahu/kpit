#ifndef PROJECT_H
#define PROJECT_H

#include <string>

class Project {
private:
    std::string _project_name;
    float _project_budget;

public:
    Project(std::string project_name, float project_budget);

    // Getter for _project_budget
    float getProjectBudget() const { return _project_budget; }
};

#endif // PROJECT_H
