#include "Employee.h"
#include "Project.h"

Employee::Employee(std::string employee_id, std::string employee_name, float salary, Project* project)
    : _employee_id(std::move(employee_id)), _employee_name(std::move(employee_name)), _salary(salary), _project(project) {}

float Employee::TextExemptionAmount() const {
    if (_salary < 1000000.0f)
        return 0.05f * _salary;
    else
        return 0.10f * _salary;
}

Employee::~Employee() {
    delete _project; // Assuming Project instance is heap-allocated
}
