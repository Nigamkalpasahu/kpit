 #include "Project.h"
 
Project::Project(std::string project_name, float project_budget)
    : _project_name(std::move(project_name)), _project_budget(project_budget) {}
