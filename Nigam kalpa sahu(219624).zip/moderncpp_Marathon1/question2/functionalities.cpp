#include "functionalities.h"
#include "Employee.h"
#include "Project.h"
#include <iostream>
#include <algorithm>
#include <numeric>

std::vector<std::unique_ptr<Employee>> createEmployees() {
    std::vector<std::unique_ptr<Employee>> employees;
    // Create and push Employee instances
    return employees;
}

int countHighBudgetProjects(const std::vector<std::unique_ptr<Employee>>& employees) {
    return std::count_if(employees.begin(), employees.end(), [](const std::unique_ptr<Employee>& emp) {
        return emp->TextExemptionAmount() > 5000.0f;
    });
}

bool allEmployeesAboveSalary(const std::vector<std::unique_ptr<Employee>>& employees) {
    return std::all_of(employees.begin(), employees.end(), [](const std::unique_ptr<Employee>& emp) {
        return emp->TextExemptionAmount() > 10000.0f;
    });
}

float averageTaxExemption(const std::vector<std::unique_ptr<Employee>>& employees) {
    float sum = std::accumulate(employees.begin(), employees.end(), 0.0f, [](float acc, const std::unique_ptr<Employee>& emp) {
        return acc + emp->TextExemptionAmount();
    });
    return sum / employees.size();
}

void displayNProjectInstances(const std::vector<std::unique_ptr<Employee>>& employees, int n) {
    if (n > employees.size()) {
        std::cerr << "Error: N exceeds the number of instances\n";
        return;
    }
    for (int i = 0; i < n; ++i) {
        // Access project details through Employee instance
     }
}

void destroyEmployees(std::vector<std::unique_ptr<Employee>>& employees) {
    employees.clear(); // Automatically deallocates memory as unique_ptrs go out of scope
}
