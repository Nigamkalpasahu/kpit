#ifndef TRANSPORTVEHICLE_H
#define TRANSPORTVEHICLE_H

#include<iostream>
#include"Permit.h"
class TransportVehicle
{
private:
    std::string _veichle_type;
    unsigned int _seat_count;
    unsigned int _stops_count;
    
public:
    
    TransportVehicle(std::string VeichleType , unsigned int SeatCount , unsigned int StopsCount)
    :_veichle_type{VeichleType} , _seat_count{SeatCount} , _stops_count{StopsCount} {}
    ~TransportVehicle() = default; 
    

    std::string veichleType() const { return _veichle_type; }

    unsigned int seatCount() const { return _seat_count; }

    unsigned int stopsCount() const { return _stops_count; }
};

#endif // TRANSPORTVEHICLE_H
