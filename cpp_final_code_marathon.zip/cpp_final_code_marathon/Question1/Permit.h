#ifndef PERMIT_H
#define PERMIT_H

#include<iostream>

class Permit
{
private:
    std::string _permit_number;
    unsigned int _permit_duration_remaining;

public:
    Permit(std::string PermitNumber , unsigned int PermitDuration )
    : _permit_number{PermitNumber} , _permit_duration_remaining{PermitDuration} {}
    ~Permit() = default;
};

#endif // PERMIT_H
