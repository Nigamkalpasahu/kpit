#include"Permit.h"
#include"TransportVehicle.h"
#include<iostream>




// average 
// float Average(unsigned int SeatCount , std::string VeichleType){
//       return 0.5*SeatCount;
// }

// bool function which going to return true false for same vehicle type 

// bool Type(std::string VeichleType ){
//     if(){

//     }
// }

