#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <vector>
#include <memory>
#include <list>
#include "TouristVehicle.h"

// Forward declaration of Permit class
class Permit;

// Function prototypes
std::vector<std::shared_ptr<TouristVehicle>> createTouristVehicles();
std::list<std::shared_ptr<TouristVehicle>> findFirstNTouristVehicles(std::vector<std::shared_ptr<TouristVehicle>>& vehicles, int n);
float averageBookingChargeByType(const std::vector<std::shared_ptr<TouristVehicle>>& vehicles, const std::string& type);
std::string getMaxChargeVehiclePermitSerial(const std::vector<std::shared_ptr<TouristVehicle>>& vehicles);

#endif // FUNCTIONALITIES_H
