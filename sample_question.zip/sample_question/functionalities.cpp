#include "functionalities.h"
#include "TouristVehicle.h"
#include "Permit.h" // Include Permit class definition

#include <algorithm>
#include <stdexcept>

std::vector<std::shared_ptr<TouristVehicle>> createTouristVehicles() {
    // Create and return a vector of TouristVehicle instances
    std::vector<std::shared_ptr<TouristVehicle>> vehicles;

    // Add TouristVehicle instances to the vector
    vehicles.push_back(std::make_shared<TouristVehicle>("ABC123", "CAB", 4, 20.0, std::make_shared<Permit>("P123", "LEASE", 30)));
    vehicles.push_back(std::make_shared<TouristVehicle>("XYZ456", "BUS", 20, 50.0, std::make_shared<Permit>("P456", "OWNED", 90)));
    vehicles.push_back(std::make_shared<TouristVehicle>("DEF789", "BIKE", 2, 10.0, std::make_shared<Permit>("P789", "LEASE", 60)));

    return vehicles;
}

std::vector<std::shared_ptr<TouristVehicle>> findFirstNTouristVehicles(const std::vector<std::shared_ptr<TouristVehicle>>& vehicles, int n) {
    // Find and return the first N TouristVehicle instances with seat count >= 4 and permit type LEASE
    std::vector<std::shared_ptr<TouristVehicle>> result;
    int count = 0;

    for (const auto& vehicle : vehicles) {
        if (vehicle->getSeatCount() >= 4 && vehicle->getPermit()->getPermitType() == "LEASE") {
            result.push_back(vehicle);
            count++;
            if (count == n) {
                break;
            }
        }
    }

    if (count < n) {
        throw std::runtime_error("Not enough vehicles meeting the criteria.");
    }

    return result;
}

float averageBookingChargeByType(const std::vector<std::shared_ptr<TouristVehicle>>& vehicles, const std::string& type) {
    // Calculate and return the average booking charge for vehicles of the given type
    float totalCharge = 0.0;
    int count = 0;

    for (const auto& vehicle : vehicles) {
        if (vehicle->getType() == type) {
            totalCharge += vehicle->getPerHourBookingCharge();
            count++;
        }
    }

    if (count == 0) {
        throw std::runtime_error("No vehicles of the specified type found.");
    }

    return totalCharge / count;
}

std::string getMaxChargeVehiclePermitSerial(const std::vector<std::shared_ptr<TouristVehicle>>& vehicles) {
    // Find the vehicle with the maximum per hour booking charge and return its permit serial number
    float maxCharge = 0.0;
    std::string maxChargeSerial;

    for (const auto& vehicle : vehicles) {
        if (vehicle->getPerHourBookingCharge() > maxCharge) {
            maxCharge = vehicle->getPerHourBookingCharge();
            maxChargeSerial = vehicle->getPermit()->getSerialNumber();
        }
    }

    if (maxChargeSerial.empty()) {
        throw std::runtime_error("No vehicles found.");
    }

    return maxChargeSerial;
}
