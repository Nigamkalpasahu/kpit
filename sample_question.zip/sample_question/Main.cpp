#include "functionalities.h"
#include <iostream>

int main() {
    try {
        // Create TouristVehicle instances
        std::vector<std::shared_ptr<TouristVehicle>> vehicles = createTouristVehicles();

        // Find and print first N TouristVehicle instances meeting criteria
        int n = 2;
        std::cout << "First " << n << " Tourist Vehicles with seat count >= 4 and permit type LEASE:" << std::endl;
        auto firstNVehicles = findFirstNTouristVehicles(vehicles, n);
        for (const auto& vehicle : firstNVehicles) {
            std::cout << "Number: " << vehicle->getNumber() << ", Seat count: " << vehicle->getSeatCount() << ", Permit type: " << vehicle->getPermit()->getPermitType() << std::endl;
        }

        // Calculate and print average booking charge for a given type
        std::string type = "CAB";
        std::cout << "Average booking charge for type " << type << ": " << averageBookingChargeByType(vehicles, type) << std::endl;

        // Find and print permit serial number of vehicle with max charge
        std::cout << "Permit serial number of vehicle with maximum per hour booking charge: " << getMaxChargeVehiclePermitSerial(vehicles) << std::endl;

    } catch (const std::exception& e) { 
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
