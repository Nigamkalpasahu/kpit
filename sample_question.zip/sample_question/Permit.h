#ifndef PERMIT_H
#define PERMIT_H

#include <string>

class Permit {
private:
    std::string _serial_number;
    std::string _permit_type;
    int _permit_duration_left;

public:
    // Constructor
    Permit(const std::string& serial_number, const std::string& permit_type, int permit_duration_left);

    // Getters
    std::string getSerialNumber() const;
    std::string getPermitType() const;
    int getPermitDurationLeft() const;
};

#endif // PERMIT_H
