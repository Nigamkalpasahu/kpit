#ifndef TOURIST_VEHICLE_H
#define TOURIST_VEHICLE_H

#include <string>
#include <memory>

// Forward declaration of Permit class
class Permit;

class TouristVehicle {
private:
    std::string _number;
    std::string _type;
    int _seat_count;
    float _per_hour_booking_charge;
    std::shared_ptr<Permit> _permit;

public:
    // Constructor
    TouristVehicle(const std::string& number, const std::string& type, int seat_count, float per_hour_booking_charge, std::shared_ptr<Permit> permit);

    // Getters
    std::string getNumber() const;
    std::string getType() const;
    int getSeatCount() const;
    float getPerHourBookingCharge() const;
    std::shared_ptr<Permit> getPermit() const;
};

#endif // TOURIST_VEHICLE_H
